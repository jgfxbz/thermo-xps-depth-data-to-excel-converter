"""
watermark_gui.py
支持PyInstaller单文件打包，水印图片嵌入exe内部
"""

import os
import sys
import tkinter as tk
from PIL import Image, ImageTk


# ================== 配置区域 ==================
POSITION = {
    "relx": 0.7,          # 横向位置：0=最左，0.5=居中，1=最右
    "rely": 0.8,          # 纵向位置：0=最上，0.5=居中，1=最下
    "anchor": "center"    # 对齐点：center / nw / ne / sw / se
}

NORMAL_SIZE = 250         # 正常水印宽度
ZOOM_SIZE = 500           # 鼠标悬停放大宽度
# =============================================


def resource_path(relative_path):
    """
    获取资源文件的绝对路径
    兼容：
    - 开发环境（直接运行.py）
    - PyInstaller单文件打包（exe内部资源）
    - PyInstaller单目录打包（外部资源）
    """
    try:
        # PyInstaller打包后的临时解压目录
        base_path = sys._MEIPASS
    except AttributeError:
        # 开发环境：当前脚本所在目录
        base_path = os.path.dirname(os.path.abspath(__file__))
    
    return os.path.join(base_path, relative_path)


class Watermark:
    def __init__(self, master, watermark_path="watermark.png",
                 normal_size=NORMAL_SIZE, zoom_size=ZOOM_SIZE):
        self.master = master
        # 使用 resource_path 获取正确路径
        self.watermark_path = resource_path(watermark_path)
        self.normal_size = normal_size
        self.zoom_size = zoom_size
        self.is_zoomed = False

        self.watermark_label = None
        self.normal_photo = None
        self.zoom_photo = None

        self.create_watermark()

    def resize_keep_ratio(self, image, target_width):
        w, h = image.size
        ratio = target_width / w
        return image.resize(
            (target_width, int(h * ratio)),
            Image.Resampling.LANCZOS
        )

    def set_position(self):
        """水印位置只由这里控制"""
        self.watermark_label.place(**POSITION)

    def create_watermark(self):
        # 检查图片是否存在（支持打包后内部路径）
        if not os.path.exists(self.watermark_path):
            print(f"❌ 找不到水印图片：{self.watermark_path}")
            print(f"   当前工作目录：{os.getcwd()}")
            print(f"   尝试在以下位置查找：{self.watermark_path}")
            return

        try:
            original_img = Image.open(self.watermark_path)

            normal_img = self.resize_keep_ratio(original_img, self.normal_size)
            zoom_img = self.resize_keep_ratio(original_img, self.zoom_size)

            self.normal_photo = ImageTk.PhotoImage(normal_img)
            self.zoom_photo = ImageTk.PhotoImage(zoom_img)

            self.watermark_label = tk.Label(
                self.master,
                image=self.normal_photo,
                bg="white",
                cursor="hand2"
            )

            self.set_position()

            self.watermark_label.bind("<Enter>", self.on_enter)
            self.watermark_label.bind("<Leave>", self.on_leave)

            print(f"✅ 水印加载成功：{self.watermark_path}")
        except Exception as e:
            print(f"❌ 水印加载失败：{e}")


    def on_enter(self, event):
        if not self.is_zoomed:
            self.is_zoomed = True
            self.watermark_label.config(image=self.zoom_photo)
            self.watermark_label.image = self.zoom_photo
            self.set_position()
            self.watermark_label.lift()

    def on_leave(self, event):
        if self.is_zoomed:
            self.is_zoomed = False
            self.watermark_label.config(image=self.normal_photo)
            self.watermark_label.image = self.normal_photo
            self.set_position()


def add_watermark_and_copyright_to_gui(
    root,
    watermark_path="watermark.png",
    copyright_text=None,
    normal_size=NORMAL_SIZE,
    zoom_size=ZOOM_SIZE
):
    watermark = Watermark(root, watermark_path, normal_size, zoom_size)

    if copyright_text is None:
        copyright_text = "脚本作者：结构分析表征 技术支持：结构分析表征 商务合作：wx:FF-JGFXBZ"

    old_title = root.title() or "软件"
    root.title(f"{old_title} | {copyright_text}")

    return watermark