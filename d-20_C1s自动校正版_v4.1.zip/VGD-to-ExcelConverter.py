# -*- coding: utf-8 -*-
"""
多层VGD to Excel Converter
从VGD文件的spectra属性中提取所有6层数据
"""

import os
import sys
import traceback
from pathlib import Path
from typing import List, Tuple, Set
from datetime import datetime

import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import vgd_reader

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
try:
    from watermark_gui import add_watermark_and_copyright_to_gui
    WATERMARK_AVAILABLE = True
except ImportError:
    WATERMARK_AVAILABLE = False
    print("⚠️ 水印模块未找到，将跳过水印功能")

# ==================== 程序信息 ====================
AUTHOR_NAME = "结构分析表征"
VERSION = "4.1"

# 蚀刻时间映射（根据您的数据）
# 注意：这些时间需要根据实际实验设置修改
ETCH_TIMES = {0: 0, 1: 60.238, 2: 306.483, 3: 614.349, 4: 924.047, 5: 1232.72}


def safe_sheet_name(name: str, used: Set[str]) -> str:
    """生成安全的工作表名称"""
    invalid_chars = '[]:*?/\\'
    for ch in invalid_chars:
        name = name.replace(ch, "_")
    name = name[:31].strip()
    if not name:
        name = "Sheet"
    original = name
    i = 1
    while name in used:
        name = f"{original[:27]}_{i}"
        i += 1
    used.add(name)
    return name


def parse_vgd_file(filepath: Path, log_func=print):
    """解析VGD文件，返回X轴数据、所有层强度和蚀刻时间"""
    obj = vgd_reader.read_vgd(str(filepath))
    
    # 获取所有谱图
    spectra = obj.spectra
    num_layers = len(spectra)
    log_func(f"      找到 {num_layers} 层谱图")
    
    if num_layers == 0:
        raise RuntimeError("未找到谱图数据")
    
    # 获取X轴（使用第一层的binding_energy，所有层应该相同）
    first_spec = spectra[0]
    if hasattr(first_spec, 'binding_energy'):
        x_data = list(first_spec.binding_energy)
    elif hasattr(first_spec, 'kinetic_energy'):
        # 如果是动能，转换为结合能（光源能量 - 动能）
        ke = list(first_spec.kinetic_energy)
        source_energy = 1486.68  # Al Ka
        x_data = [source_energy - e for e in ke]
    else:
        raise RuntimeError("无法获取X轴数据")
    
    # 获取每层的强度
    all_y_data = []
    for spec in spectra:
        if hasattr(spec, 'intensity'):
            y = list(spec.intensity)
        elif hasattr(spec, 'corrected_intensity'):
            y = list(spec.corrected_intensity)
        else:
            raise RuntimeError(f"谱图缺少强度数据")
        all_y_data.append(y)
    
    # 获取蚀刻时间（从字典或索引）
    etch_times = []
    for i in range(num_layers):
        if i in ETCH_TIMES:
            etch_times.append(ETCH_TIMES[i])
        else:
            etch_times.append(i)
    
    return x_data, all_y_data, etch_times



# ==================== C1s 自动能量校正 ====================
def find_c1s_peak_shift(x_data, y_data, ref=284.8):
    """在C1s范围280-288 eV寻找最高峰并计算校正量"""
    pairs=[]
    for x,y in zip(x_data,y_data):
        try:
            if 280 <= float(x) <= 288:
                pairs.append((float(x), float(y)))
        except Exception:
            pass
    if not pairs:
        raise ValueError("未找到C1s范围(280-288 eV)数据")
    peak=max(pairs, key=lambda z:z[1])[0]
    return ref-peak, peak


class VGDConverterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"VGD to Excel 转换器 v{VERSION}")
        self.geometry("900x650")
        self.configure(bg="#f0f0f0")
        
        self.input_dir = tk.StringVar()
        self.output_file = tk.StringVar()
        self.calibration_mode = tk.StringVar(value="none")
        
        self._build()
        # ==================== 添加水印 ====================
        if WATERMARK_AVAILABLE:
            try:
                self.watermark = add_watermark_and_copyright_to_gui(
                    self,
                    watermark_path="watermark.png",
                    copyright_text="脚本作者：结构分析表征 技术支持：光电子能谱分部 商务合作：wx:FF-JGFXBZ",
                    normal_size=200,
                    zoom_size=400
                )
                print("✅ 水印加载成功")
            except Exception as e:
                print(f"❌ 水印加载失败: {e}")
        else:
            self.title(f"VGD to Excel 转换器 v{VERSION} | 脚本作者：结构分析表征")
        # =================================================      
        
    def _build(self):
        main_frame = tk.Frame(self, bg="#f0f0f0")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # 标题
        title_frame = tk.Frame(main_frame, bg="#2c3e50", height=50)
        title_frame.pack(fill="x", pady=(0, 10))
        title_frame.pack_propagate(False)
        tk.Label(title_frame, text="VGD to Excel 转换器 - 多层数据导出", 
                 font=("微软雅黑", 12, "bold"), fg="white", bg="#2c3e50").pack(expand=True)
        
        # 输入文件夹
        input_frame = tk.LabelFrame(main_frame, text="步骤1: 选择包含 .vgd 文件的文件夹", 
                                     font=("微软雅黑", 10, "bold"), padx=10, pady=5)
        input_frame.pack(fill="x", pady=5)
        
        f1 = tk.Frame(input_frame)
        f1.pack(fill="x", pady=5)
        tk.Entry(f1, textvariable=self.input_dir, width=80).pack(side="left", fill="x", expand=True)
        tk.Button(f1, text="浏览", command=self.choose_input, bg="#4CAF50", fg="white", width=8).pack(side="right", padx=5)
        
        # 输出文件
        output_frame = tk.LabelFrame(main_frame, text="步骤2: 输出Excel文件", 
                                      font=("微软雅黑", 10, "bold"), padx=10, pady=5)
        output_frame.pack(fill="x", pady=5)
        
        f2 = tk.Frame(output_frame)
        f2.pack(fill="x", pady=5)
        tk.Entry(f2, textvariable=self.output_file, width=80).pack(side="left", fill="x", expand=True)
        tk.Button(f2, text="保存为", command=self.choose_output, bg="#2196F3", fg="white", width=8).pack(side="right", padx=5)
        
        # C1s校正选项
        calib_frame = tk.LabelFrame(main_frame, text="C1s能量自动校正(284.8 eV)", font=("微软雅黑",10,"bold"), padx=10, pady=5)
        calib_frame.pack(fill="x", pady=5)
        ttk.Radiobutton(calib_frame, text="不校正", variable=self.calibration_mode, value="none").pack(anchor="w")
        ttk.Radiobutton(calib_frame, text="A方案：读取level 0层C1s最高峰，校正全部层", variable=self.calibration_mode, value="A").pack(anchor="w")
        ttk.Radiobutton(calib_frame, text="B方案：读取每层C1s最高峰，每层分别校正", variable=self.calibration_mode, value="B").pack(anchor="w")

        # 按钮
        tk.Button(main_frame, text="开始转换", command=self.convert, 
                  bg="#FF9800", fg="white", font=("微软雅黑", 12, "bold"), 
                  padx=30, pady=8).pack(pady=15)
        
        # 日志
        log_frame = tk.LabelFrame(main_frame, text="转换日志", font=("微软雅黑", 10, "bold"), padx=10, pady=5)
        log_frame.pack(fill="both", expand=True, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, font=("Consolas", 9))
        self.log_text.pack(fill="both", expand=True)
        
        # 底部信息
        info_bar = tk.Frame(main_frame, bg="#f5f5f5", height=25)
        info_bar.pack(fill="x", pady=(5, 0))
        info_bar.pack_propagate(False)
        tk.Label(info_bar, text=f"技术支持: 光电子能谱分部", font=("微软雅黑", 9), 
                 fg="#666", bg="#f5f5f5").pack(expand=True)
        
        self.log("=" * 60)
        self.log(f"VGD to Excel 转换器 v{VERSION}")
        self.log(f"作者: {AUTHOR_NAME}")
        self.log("=" * 60)
        self.log("功能: 将VGD文件中的多层数据导出到Excel，每层独立显示")
        self.log("=" * 60)
        
    def log(self, msg):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {msg}\n")
        self.log_text.see("end")
        self.update()
    
    def choose_input(self):
        d = filedialog.askdirectory()
        if d:
            self.input_dir.set(d)
            self.output_file.set(str(Path(d) / "VGD_Data_Converted.xlsx"))
    
    def choose_output(self):
        f = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if f:
            self.output_file.set(f)
    
    def convert(self):
        if not self.input_dir.get():
            messagebox.showerror("错误", "请选择文件夹")
            return
        
        input_path = Path(self.input_dir.get())
        output_path = Path(self.output_file.get())
        
        # 查找所有VGD文件
        files = list(input_path.rglob("*.vgd")) + list(input_path.rglob("*.VGD"))
        files = list({str(f): f for f in files}.values())
        
        if not files:
            self.log("未找到.vgd文件")
            messagebox.showerror("错误", "未找到.vgd文件")
            return
        
        self.log(f"\n找到 {len(files)} 个VGD文件")
        
        wb = Workbook()
        wb.remove(wb.active)
        used = set()
        
        thin = Side(style="thin", color="D9D9D9")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        header_fill = PatternFill("solid", fgColor="D9EAF7")
        
        for f in files:
            self.log(f"\n处理: {f.name}")
            
            try:
                x_data, all_y_data, etch_times = parse_vgd_file(f, self.log)
                num_layers = len(all_y_data)

                # C1s自动校正
                mode=self.calibration_mode.get()
                if mode == "A":
                    shift, peak = find_c1s_peak_shift(x_data, all_y_data[0])
                    all_y_data = [y[:] for y in all_y_data]
                    x_data = [xx + shift for xx in x_data]
                    self.log(f"  A方案: level0 C1s峰={peak:.4f} eV, 全部谱图校正 {shift:+.4f} eV")
                elif mode == "B":
                    shifts=[]
                    for li,y in enumerate(all_y_data):
                        try:
                            shift, peak=find_c1s_peak_shift(x_data,y)
                            shifts.append(shift)
                            self.log(f"  B方案: layer{li} C1s峰={peak:.4f} eV, 校正 {shift:+.4f} eV")
                        except Exception as e:
                            shifts.append(0)
                            self.log(f"  layer{li} 未找到C1s，跳过校正")
                    # B方案需要每层独立X轴，后续写入时使用
                else:
                    shifts=[0]*num_layers

                self.log(f"  数据: X轴 {len(x_data)} 点, {num_layers} 层")
                for i, y in enumerate(all_y_data):
                    self.log(f"    层{i}: EtchTime={etch_times[i]}s, 强度 {min(y):.2f}~{max(y):.2f}")
                
                # 创建工作表
                sheet_name = safe_sheet_name(f.stem, used)
                ws = wb.create_sheet(sheet_name)
                
                current_col = 1
                for layer_idx in range(num_layers):
                    y_data = all_y_data[layer_idx]
                    etch_time = etch_times[layer_idx]
                    layer_shift = shifts[layer_idx] if (mode == "B") else 0
                    
                    # 层标签
                    layer_label = f"EtchTime={etch_time}s  EtchLevel={layer_idx}"
                    ws.merge_cells(start_row=1, start_column=current_col, 
                                   end_row=1, end_column=current_col+1)
                    cell = ws.cell(row=1, column=current_col, value=layer_label)
                    cell.font = Font(bold=True, size=10)
                    cell.fill = header_fill
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.border = border
                    
                    # 列标题
                    ws.cell(row=2, column=current_col, value="Binding Energy (eV)").font = Font(bold=True)
                    ws.cell(row=2, column=current_col+1, value="Intensity (cps)").font = Font(bold=True)
                    ws.cell(row=2, column=current_col).fill = header_fill
                    ws.cell(row=2, column=current_col+1).fill = header_fill
                    ws.cell(row=2, column=current_col).border = border
                    ws.cell(row=2, column=current_col+1).border = border
                    
                    # 数据
                    for row_idx in range(len(x_data)):
                        ws.cell(row=row_idx + 3, column=current_col, value=x_data[row_idx] + layer_shift).border = border
                        if row_idx < len(y_data):
                            ws.cell(row=row_idx + 3, column=current_col+1, value=y_data[row_idx]).border = border
                    
                    # 列宽
                    ws.column_dimensions[get_column_letter(current_col)].width = 18
                    ws.column_dimensions[get_column_letter(current_col + 1)].width = 15
                    
                    current_col += 3
                
                self.log(f"  完成! 保存到工作表: {sheet_name}")
                
            except Exception as e:
                self.log(f"  错误: {e}")
                continue
        
        if len(wb.sheetnames) == 0:
            self.log("没有成功读取任何文件")
            messagebox.showerror("错误", "没有成功读取任何文件")
            return
        
        # 信息工作表
        info_ws = wb.create_sheet("【关于本文件】", 0)
        info_ws["A1"] = "本文件由VGD to Excel转换器生成"
        info_ws["A2"] = f"版本: {VERSION}"
        info_ws["A3"] = f"作者: {AUTHOR_NAME}"
        info_ws["A4"] = f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        info_ws["A5"] = "说明: 每层数据独立（X轴+Y轴），按蚀刻时间从左到右排列"
        info_ws.column_dimensions["A"].width = 50
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(output_path)
        self.log(f"\n✅ 转换完成! 保存至: {output_path}")
        messagebox.showinfo("完成", f"转换完成!\n{output_path}")


def main():
    app = VGDConverterApp()
    app.mainloop()


if __name__ == "__main__":
    main()